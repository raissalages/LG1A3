public class ExcecaoContemNumero extends RuntimeException {

    public ExcecaoContemNumero() {
        System.out.println("O nome contém um numero.");
    }


}
